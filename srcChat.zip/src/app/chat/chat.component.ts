import { Component, Inject, LOCALE_ID } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Mensaje } from '../mensaje';
import { ServicioServiceService } from '../servicio-service.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent {
cerrarSesion() {
  if(sessionStorage.getItem("nombre") != null && sessionStorage.getItem("nombre") != undefined){
    sessionStorage.removeItem("nombre");
    window.location.reload();
  }
}
  texto: string="";
  usuario: string="";
  listaMensajes: Mensaje[]=[];
  mensaje: Mensaje = new Mensaje();
  dataSource = new MatTableDataSource<Mensaje>();
  displayedColumns: String[] = ['id', 'fecha', 'usuario', 'mensaje', 'activo'];

  constructor(private servicio:ServicioServiceService){
    const nombreUsuario = sessionStorage.getItem("nombre");
    if(nombreUsuario != null){
      this.usuario = nombreUsuario;
      this.refrescar();
    }else{
      alert("Ningun usuario logueado, logueate primero para continuar");
    }
  }

  refrescar() {
  this.servicio.leerMensajes().subscribe(x => {
    this.dataSource.data = x;
  });
  }
  enviarMensaje() {
    if(this.usuario != null && this.usuario != ""){
      this.mensaje.usuario= this.usuario;
      this.mensaje.mensaje=this.texto;
      this.servicio.escribirMensaje(this.mensaje).subscribe();
      this.texto = "";
    }else{
      alert("No puede enviar mensaje sin estar logueado")
    }
  }
}
