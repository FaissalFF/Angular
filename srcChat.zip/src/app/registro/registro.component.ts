import { Component } from '@angular/core';
import { ServicioServiceService } from '../servicio-service.service';
import { Usuario } from '../usuario';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent {
usuario: string = "";
email: string= "";
contra: string = "";
  constructor(private servicio: ServicioServiceService){
  }
    registrar() {
      let us = new Usuario();
      us.nombre=  this.usuario;
      us.email = this.email;
      us.pwd = this.contra;
      us.activo = true;
      this.servicio.altaCliente(us).subscribe();
      alert("Usuario creado correctamente")
    }
}
