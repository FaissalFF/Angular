import { Component } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Mensaje } from '../mensaje';
import { ServicioServiceService } from '../servicio-service.service';
import { Usuario } from '../usuario';

@Component({
  selector: 'app-chat-admin',
  templateUrl: './chat-admin.component.html',
  styleUrls: ['./chat-admin.component.css']
})
export class ChatAdminComponent {
recursoUsuarios = new MatTableDataSource<Usuario>();
ActivarUsuario(usuario: Usuario) {
  this.servicio.activarUsuario(usuario).subscribe(x=>{
    this.mostrarUsers();
  });
}
bloquearUsuario(usuario: Usuario) {
this.servicio.bloquearUsuario(usuario).subscribe(x=>{
  this.mostrarUsers();
});
}
mostrarUsers() {
  if(sessionStorage.getItem("nombre") == "admin"){
    if(this.mostrados == false){
      this.mostrados = true;
      this.servicio.obtenerUsuarios().subscribe(x=> {
        this.recursoUsuarios.data = x;
      });
    }else{
      this.mostrados = false;
      this.recursoUsuarios = new MatTableDataSource<Usuario>();
    }
  }
}
cerrarSesion() {
  if(sessionStorage.getItem("nombre") != null && sessionStorage.getItem("nombre") != undefined){
    sessionStorage.removeItem("nombre");
    window.location.reload();
  }
}
ActivarMensaje(mensaje:Mensaje) {
  this.servicio.activarMensaje(mensaje).subscribe(x=>{
    this.refrescar();
  });
}
bloquearMensaje(mensaje:Mensaje) {
  this.servicio.bloquearMensaje(mensaje).subscribe(x=>{
    this.refrescar();
  }
  );
}
  listaMensajes: Mensaje[]=[];
  mensaje: Mensaje = new Mensaje();
  dataSource = new MatTableDataSource<Mensaje>();
  displayedColumns: String[] = ['id', 'fecha', 'usuario', 'mensaje', 'activo', 'herramientas'];
  mostrados:Boolean = false;
  constructor(private servicio:ServicioServiceService){
    if(sessionStorage.getItem("nombre") != null && sessionStorage.getItem("nombre") != undefined){
      this.refrescar();
    }
  }
  refrescar() {
    this.servicio.leerMensajesAdmin().subscribe(x => {
      this.dataSource.data = x;
    });
    }
}
