import { Component } from '@angular/core';
import { ServicioServiceService } from './servicio-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ChatMaterials';
  getRouterLink(): string {
    if(sessionStorage.getItem("nombre") == "admin"){
      return 'chatAdmin';
    }else{
      return 'chat';
    }
  }
}
