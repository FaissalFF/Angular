export class Usuario {
    idUsuario!: number;
    nombre!: string;
    email!: string;
    pwd!: string;
    activo!: boolean;
}
