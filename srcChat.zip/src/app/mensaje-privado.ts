export class MensajePrivado {
  id!: number;
  fecha!: string;
  usuario!: string;
  mensaje!: string;
  activo!:number;
  destinatario!:string;
}
