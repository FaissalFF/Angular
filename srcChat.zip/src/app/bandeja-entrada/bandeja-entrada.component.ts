import { Component } from '@angular/core';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { MensajePrivado } from '../mensaje-privado';
import { ServicioServiceService } from '../servicio-service.service';

@Component({
  selector: 'app-bandeja-entrada',
  templateUrl: './bandeja-entrada.component.html',
  styleUrls: ['./bandeja-entrada.component.css']
})
export class BandejaEntradaComponent {
dataSource= new MatTableDataSource<MensajePrivado>();
nomUs:string = "";
displayedColumns: String[] = ['id', 'fecha', 'usuario', 'mensaje'];
constructor(private servicio: ServicioServiceService){
  const nombre = sessionStorage.getItem("nombre");
  if(nombre != null){
      this.nomUs = nombre;
      this.obtenerMensajesPrivados();
  }

}
obtenerMensajesPrivados(){
this.servicio.obtenerMensajesPrivados(this.nomUs).subscribe(x=>{
this.dataSource.data = x;
});
}
}
