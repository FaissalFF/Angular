import { Component } from '@angular/core';
import { ServicioServiceService } from '../servicio-service.service';
import { Usuario } from '../usuario';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
usuario: string="";
contra: string="";
  constructor(private servicio:ServicioServiceService){
  }
loguear() {
  let us = new Usuario();
  us.email = this.usuario;
  us.pwd = this.contra;
  this.servicio.seleccionarUsuario(us).subscribe(x=>{
    if(x != null && x != undefined){
      sessionStorage.setItem("nombre", x[0].nombre);
      alert("Has iniciado sesión correctamente")
    }else{
      alert("Usuario no encontrado")
    }
  });
}
}
