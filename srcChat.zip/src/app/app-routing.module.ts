import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BandejaEntradaComponent } from './bandeja-entrada/bandeja-entrada.component';
import { ChatAdminComponent } from './chat-admin/chat-admin.component';
import { ChatComponent } from './chat/chat.component';
import { ChatprivadoComponent } from './chatprivado/chatprivado.component';
import { LoginComponent } from './login/login.component';
import { RegistroComponent } from './registro/registro.component';

const routes: Routes = [
  {
    path: 'chat',
    component: ChatComponent,
  },
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'registro',
    component: RegistroComponent,
  },
  {
    path: 'chatAdmin',
    component: ChatAdminComponent,
  },
  {
    path: 'chatprivado',
    component: ChatprivadoComponent,
  },
  {
    path: 'bandejaEntrada',
    component: BandejaEntradaComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
