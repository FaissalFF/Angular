import { Component } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Mensaje } from '../mensaje';
import { MensajePrivado } from '../mensaje-privado';
import { ServicioServiceService } from '../servicio-service.service';
import { Usuario } from '../usuario';

@Component({
  selector: 'app-chatprivado',
  templateUrl: './chatprivado.component.html',
  styleUrls: ['./chatprivado.component.css']
})
export class ChatprivadoComponent {
mostrarHistorial() {
  if(this.historialMostrado == false){
    this.historialMostrado = true;
    this.servicio.obtenerHistorialMensajes(this.nombreusuario).subscribe(x=>{
      this.historialMensaje.data = x;
      });
  }else{
    this.historialMensaje = new MatTableDataSource<MensajePrivado>();
  }

}
mensaje:MensajePrivado = new MensajePrivado();
historialMensaje= new MatTableDataSource<MensajePrivado>();
columnasHistorial: String[] = ['id', 'fecha', 'usuario', 'mensaje'];
obtenerUsuario(usuario: any) {
  this.user = usuario.nombre;
  this.usuario = usuario;
}
mostrados:boolean = false;
usuario = new Usuario;
user: string= "";
nombreusuario: string = "";
historialMostrado:boolean = false;
enviarMensaje() {
  if(sessionStorage.getItem("nombre") != null){
    this.mensaje.usuario= this.nombreusuario;
    this.mensaje.mensaje=this.texto;
    this.mensaje.destinatario = this.user;
    this.mensaje.activo = 1;
    this.servicio.enviarMensajePrivado(this.mensaje).subscribe();
    this.texto = "";
  }
}
recursoUsuarios= new MatTableDataSource<Usuario>();
displayedColumns: String[] = ['id', 'nombre', 'email', 'herramientas'];
texto: string="";
constructor(private servicio: ServicioServiceService){
    const nomUs = sessionStorage.getItem("nombre");
  if(nomUs != null && nomUs != undefined){
    this.nombreusuario = nomUs;
  }else{
    alert("No puede acceder al chat sin antes iniciar sesión");
  }
}
mostrarUsers() {
  if(this.mostrados == false){
    this.mostrados = true;
    this.servicio.obtenerUsuarios().subscribe(x=> {
      this.recursoUsuarios.data = x;
    });
  }else{
    this.recursoUsuarios =new MatTableDataSource<Usuario>();
}
}
}
