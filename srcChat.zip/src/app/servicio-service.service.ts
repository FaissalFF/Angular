import { Inject, Injectable, LOCALE_ID } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient} from '@angular/common/http'
import { Mensaje } from './mensaje';
import { formatDate } from '@angular/common';
import { Usuario } from './usuario';
import { MensajePrivado } from './mensaje-privado';

@Injectable({
  providedIn: 'root'
})
export class ServicioServiceService {
  activarUsuario(usuario: Usuario) {
    return this.httpCliente.put<Usuario>('http://moralo.atwebpages.com/chat/ActivarUsuario.php', usuario);
  }
  bloquearUsuario(usuario: Usuario) {
    return this.httpCliente.put<Usuario>('http://moralo.atwebpages.com/chat/BloquearUsuario.php', usuario);
  }
  activarMensaje(mensaje: Mensaje) {
    return this.httpCliente.put<Mensaje>('http://moralo.atwebpages.com/chat/ActivarMensaje.php',mensaje);
  }
  bloquearMensaje(mensaje: Mensaje) {
    return this.httpCliente.put<Mensaje>('http://moralo.atwebpages.com/chat/BloquearMensaje.php',mensaje);
  }
  obtenerUsuarios():Observable<Usuario[]>{
    return this.httpCliente.get<Usuario[]>('http://moralo.atwebpages.com/menuAjax/chat/ObtenerUsuarios.php');
  }
  enviarMensajePrivado(mensajeP:MensajePrivado){
    let fecha = new Date();
    mensajeP.fecha=formatDate(fecha,"HH:mm:ss/dd-mm-yyyy",this.locale);
    return this.httpCliente.put<MensajePrivado>('http://moralo.atwebpages.com/menuAjax/chat/AltaMensajeP.php', mensajeP);
  }
  obtenerMensajesPrivados(nombreUsuario: string):Observable<MensajePrivado[]>{
    return this.httpCliente.get<MensajePrivado[]>('http://moralo.atwebpages.com/menuAjax/chat/ObtenerMensajesP.php?usuario=' + nombreUsuario);
  }
  obtenerHistorialMensajes(nombreUsuario:string):Observable<MensajePrivado[]>{
    return this.httpCliente.get<MensajePrivado[]>('http://moralo.atwebpages.com/menuAjax/chat/ObtenerMensajesE.php?usuario='+ nombreUsuario);
  }
  constructor(private httpCliente:HttpClient,  @Inject(LOCALE_ID) public locale: string){

  }
  escribirMensaje(mensaje: Mensaje) {
    let fecha = new Date();
    mensaje.fecha=formatDate(fecha,"HH:mm:ss/dd-mm-yyyy",this.locale);
    mensaje.activo = 1;
    return this.httpCliente.put<Mensaje>('http://moralo.atwebpages.com/menuAjax/chat/AltaMensaje.php',mensaje)
  }
  leerMensajes():Observable<Mensaje[]> {
    return this.httpCliente.get<Mensaje[]>('http://moralo.atwebpages.com/menuAjax/chat/ObtenerMensajes2.php')
  }
  leerMensajesAdmin():Observable<Mensaje[]> {
    return this.httpCliente.get<Mensaje[]>('http://moralo.atwebpages.com/menuAjax/chat/ObtenerMensajes.php')
  }
  altaCliente(user: Usuario){
    return this.httpCliente.post<Usuario>("http://moralo.atwebpages.com/menuAjax/chat/AltaUsuario.php", user);
  }

  seleccionarUsuario(user: Usuario) :Observable<Usuario[]>{
    return this.httpCliente.get<Usuario[]>("http://moralo.atwebpages.com/menuAjax/chat/SeleccionarUsuario.php?email="+user.email+"&pwd="+user.pwd);
  }
}
